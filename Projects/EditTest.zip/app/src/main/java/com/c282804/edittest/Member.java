package com.c282804.edittest;

public class Member {

    String name;
    String nick;
    String title;
    String write;

    public Member(String name, String nick, String title, String write){
        this.name=name;
        this.nick=nick;
        this.title=title;
        this.write=write;
    }
}
